var scrollPosition;
var mouseHist;

function setup() {
  createCanvas(400, 400, WEBGL);
  scrollPosition = 0;
  mouseHist = [];
}

function draw() {
  background(220);

  // push();
  // 		rotateX(millis() / 200);
		// rotateZ(scrollPosition / 100);
		// box(200);
  // pop();

  var curr = [mouseX, mouseY];
  append(mouseHist, [mouseX - width / 2, mouseY - height / 2]);
  if (mouseHist.length > 50) {
  	// mouseHist.shift();
  	mouseHist.splice(0, 2);
  }

  stroke(color(0, 0, 0));
  for (var i = 0; i < mouseHist.length - 1; i++) {
  	line(mouseHist[i][0], mouseHist[i][1], mouseHist[i + 1][0], mouseHist[i + 1][1])
  }
}

function mouseClicked() {
	console.log(mouseHist);
  if (mouseX >= 100 && mouseX <= 300) {
  	if (mouseY >= 100 && mouseY <= 200) {
  		console.log("HELLO");
  		fill(color(random(255), random(255), random(255)));
  	}
  }
}

function mouseWheel(event) {
  scrollPosition += event.wheelDelta;
}