var scrollPosition;

function setup() {
  createCanvas(400, 400, WEBGL);
  scrollPosition = 0;
}

function draw() {
  background(220);

  push();
  		rotateX(millis() / 200);
		rotateZ(scrollPosition / 100);
		box(200);
  pop();

  console.log(scrollPosition);
}

function mouseClicked() {
  if (mouseX >= 100 && mouseX <= 300) {
  	if (mouseY >= 100 && mouseY <= 200) {
  		console.log("HELLO");
  		fill(color(random(255), random(255), random(255)));
  	}
  }
}

function mouseWheel(event) {
  scrollPosition += event.wheelDelta;
}